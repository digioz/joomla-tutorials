<?php
defined('_JEXEC') or die ("Access Denied");

echo "<h3>Welcome to MyComp Frontend</h3>";