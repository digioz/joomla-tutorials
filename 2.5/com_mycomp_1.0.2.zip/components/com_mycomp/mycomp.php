<?php
defined('_JEXEC') or die ("Access Denied");

echo JText::_('COM_MYCOMP_WELCOME');