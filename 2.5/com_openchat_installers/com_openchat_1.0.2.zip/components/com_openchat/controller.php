<?php
defined('_JEXEC') or die ('Access Denied');

jimport('joomla.application.component.controller');

class OpenChatController extends JController
{
	function chat() {
		echo "Welcome to chat form";
	}
}