DROP TABLE IF NOT EXISTS #__openchat_msg;
DROP TABLE IF NOT EXISTS #__openchat_blocked_users;