<?php
defined('_JEXEC') or die ("Access Denied");
jimport('joomla.application.component.controller');

// Create controller instance
$controller=JController::getInstance('MyComp');

// Execute Task
$controller->execute(JRequest::getCmd('task'));

// If redirect set
$controller->redirect();

echo JText::_('COM_MYCOMP_WELCOME');