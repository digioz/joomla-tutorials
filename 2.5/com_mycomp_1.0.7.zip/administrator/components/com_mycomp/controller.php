<?php
defined('_JEXEC') or die ('Access Denied');
jimport('joomla.application.componenet.controller');

class MyCompController extends JController {

	function display() {
		echo JText::_('COM_MYCOMP_WELCOME');
	}

	function create() {
		echo JText::_('COM_MYCOMP_TASK_CREATE');
	}
	
	function delete() {
		echo JText::_('COM_MYCOMP_TASK_DELETE');
	}
	
	function listtask() {
		echo JText::_('COM_MYCOMP_TASK_LISTTASK');
	}
	
	function help() {
		echo JText::_('COM_MYCOMP_TASK_HELP');
		echo '<h1>This is the Help Task <input type="text">';
	}
}