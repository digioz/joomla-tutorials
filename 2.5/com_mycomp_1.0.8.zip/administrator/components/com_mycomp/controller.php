<?php
defined('_JEXEC') or die ('Access Denied');
jimport('joomla.application.componenet.controller');

class MyCompController extends JController {

	function display() {
		JToolBarHelper::Title('My Component');
		echo JText::_('COM_MYCOMP_WELCOME');
	}

	function create() {
		JToolBarHelper::Title('Create New Task');
		echo JText::_('COM_MYCOMP_TASK_CREATE');
	}
	
	function listtask() {
		JToolBarHelper::Title('List All Tasks');
		echo JText::_('COM_MYCOMP_TASK_LISTTASK');
	}
	
	function help() {
		JToolBarHelper::Title('Help Documentation');
		echo JText::_('COM_MYCOMP_TASK_HELP');
		echo '<h1>This is the Help Task <input type="text">';
	}
	
	function delete() {
		JToolBarHelper::Title('My Component');
		echo JText::_('COM_MYCOMP_TASK_DELETE');
	}
	

}