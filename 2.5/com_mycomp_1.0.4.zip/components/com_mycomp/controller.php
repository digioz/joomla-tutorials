<?php

defined('_JEXEC') or die ('Access Denied');
jimport('joomla.application.component.controller');

class MyCompController extends JController {

	function display() {
		echo JText::_('COM_MYCOMP_WELCOME');
	}

	function create(){
		echo "Welcome to Create";
	}
	
	function delete(){
		$id = JRequest::getInt('id');
		echo "You want to delete $id"; 
	}
}