<?php
defined('_JEXEC') or die ('Access Denied');
jimport('joomla.application.componenet.controller');

class MyCompController extends JController {

	function display() {
		echo JText::_('COM_MYCOMP_WELCOME');
	}

	function create() {
		echo JText::_('COM_MYCOMP_TASK_CREATE');
	}
	
	function delete() {
		echo JText::_('COM_MYCOMP_TASK_DELETE');
	}
}